# ASAPP Chat Backend Challenge v1
### Overview
This is a java based boilerplate which runs s HTTP Server configured to answer the endpoints defined in 
[the challenge you received](https://asappinc.github.io/challenge-backend/).
All endpoints are configured in src/main/java/com/asapp/backend/challenge/Application.java and if you go deeper to the
Routes and Filters passed as second parameters, you will find a TODO comment where you are free to implement your solution.

### How to run it
```$xslt
gradle run
```


##### Note
This file can be removed/modified by the candidate in order to create a proper document for the project to be presented.

