package com.asapp.backend.challenge.controller;

import com.asapp.backend.challenge.resources.MessageResource;
import com.asapp.backend.challenge.utils.JSONUtil;
import spark.Request;
import spark.Response;
import spark.Route;

import java.util.Arrays;

public class MessagesController {

    public static Route sendMessage = (Request req, Response rep) -> {
        // TODO Allow messages of the logged user to be stored
        return JSONUtil.dataToJson(new MessageResource());
    };

    public static Route getMessages = (Request req, Response rep) -> {
        // TODO Allow messages related to the logged user to be retrieved
        return JSONUtil.dataToJson(Arrays.asList(new MessageResource()));
    };

}
