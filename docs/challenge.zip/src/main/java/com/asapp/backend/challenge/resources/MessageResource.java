package com.asapp.backend.challenge.resources;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MessageResource {

    private Integer id;

    private Integer sender;

    private Integer recipient;

    private MessageContentResource content;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSender() {
        return sender;
    }

    public void setSender(Integer sender) {
        this.sender = sender;
    }

    public Integer getRecipient() {
        return recipient;
    }

    public void setRecipient(Integer recipient) {
        this.recipient = recipient;
    }

    public MessageContentResource getContent() {
        return content;
    }

    public void setContent(MessageContentResource content) {
        this.content = content;
    }
}
