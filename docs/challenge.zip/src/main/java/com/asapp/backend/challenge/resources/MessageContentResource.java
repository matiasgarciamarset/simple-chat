package com.asapp.backend.challenge.resources;

public class MessageContentResource {

    private MessageContentResourceType type;

    private String text;

    private String url;

    private int height;

    private int width;

    public MessageContentResourceType getType() {
        return type;
    }

    public void setType(MessageContentResourceType type) {
        this.type = type;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }
}
