package com.asapp.backend.challenge.controller;

import com.asapp.backend.challenge.resources.UserResource;
import com.asapp.backend.challenge.utils.JSONUtil;
import spark.Request;
import spark.Response;
import spark.Route;

public class UsersController {

    public static Route createUser = (Request req, Response resp) -> {
        // TODO Create User must create a new User into the system taking into account that two users can't have the same
        //  email
        UserResource data = new UserResource();
        data.setId(2);
        return JSONUtil.dataToJson(data);
    };
}
