package com.asapp.backend.challenge.filter;

import spark.Filter;
import spark.Request;
import spark.Response;
import spark.Spark;

public class TokenValidatorFilter {

    public static Filter validateUser = (Request req, Response resp) -> {
        boolean isTokenValid = false;
        // TODO validate
        if (!isTokenValid) {
            Spark.halt(401, "Not valid token");
        }
    };
}
