package com.asapp.backend.challenge.resources;

public class LoginResponseResource {

    private int id;

    private String token;

    public LoginResponseResource(int id, String token) {
        this.id = id;
        this.token = token;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
