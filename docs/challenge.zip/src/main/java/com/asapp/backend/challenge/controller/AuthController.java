package com.asapp.backend.challenge.controller;

import com.asapp.backend.challenge.resources.LoginResponseResource;
import com.asapp.backend.challenge.utils.JSONUtil;
import spark.*;

public class AuthController {

    public static Route login = (Request req, Response resp) -> {
        // TODO User must Login and a token must be generated
        return JSONUtil.dataToJson(new LoginResponseResource(0, "token"));
    };

}
